class DeezerKodiException(Exception):
    """
    Base exception for every DeezerKodi API exceptions.
    """
