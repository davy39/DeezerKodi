"""
Package for communcating with Deezer API
"""

from .api import Api
from .router import Router
