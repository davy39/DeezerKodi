"""
The views package defines how to display different objects.
"""
