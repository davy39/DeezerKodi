"""
This module contains helpers functions for the entire addon.
"""
